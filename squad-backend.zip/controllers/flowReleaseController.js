const { sequelize } = require("../models");
const { iot_oci1 } = require("../config/connection");
const { iot_oci2 } = require("../config/connection");

module.exports = {
    getFlowReleaseOCI1: async (req, res) => {
        try {
            let query;
            query = await iot_oci1.query(`
            SELECT 
    a.tgl,
    a.lotno,
    a.prod_order,
    a.product,
    DATEDIFF(NOW(), a.prod_start) AS fg_quarantine,
    IF(SUM(mikro.simpulan) = 0, 7, 0) AS sim_mikro,
    IF(SUM(ipc.simpulan) = 0, 7, 0) AS sim_ipc,
    COUNT(inspeksi.id) AS inspeksi,
    COUNT(capa.id) AS capa,
    COUNT(form.id) as dynamic_form,
    SUM(ccp.total_jumlah) as ccp
FROM 
    mst_prodidentity a
LEFT JOIN 
    (
        SELECT
            lotno,
            CASE
                WHEN (b.name = 'ALVIN JAUHAR AL KHOIR') THEN 0
                ELSE -1
            END AS simpulan
        FROM
            tr_history2 a
        JOIN
            v_employee b ON a.job_owner = b.nik
        WHERE 
            a.tgl_proses IS NOT NULL AND b.name = 'ALVIN JAUHAR AL KHOIR'
    ) mikro ON a.lotno = mikro.lotno
LEFT JOIN 
    (
        SELECT
            lotno,
            CASE
                WHEN (b.name = 'HARY AGUSTIAWAN') THEN 0
                ELSE -1
            END AS simpulan
        FROM
            tr_history2 a
        JOIN
            v_employee b ON a.job_owner = b.nik
        WHERE 
            a.tgl_proses IS NOT NULL AND b.name = 'HARY AGUSTIAWAN'
    ) ipc ON a.lotno = ipc.lotno
LEFT JOIN 
    (
        SELECT
            id,
            pro,
            status_approval
        FROM
            aio_iot_oci1.tr_inspection_capa_h
        WHERE 
            status_approval >= 1
    ) inspeksi on a.prod_order = inspeksi.pro
LEFT JOIN 
    (
        SELECT
            id,
            pro,
            status_approval
        FROM
            aio_iot_oci1.tr_inspection_capa_h
        WHERE 
            status_approval = 4
    ) capa on a.prod_order = capa.pro
LEFT JOIN 
    (
        SELECT 
            id,
            lotno,
            pro
        FROM 
            tr_summary_perilisan
    ) form on a.lotno = form.lotno
LEFT JOIN 
    (
        SELECT 
            prod_order1,
            SUM(jumlah) AS total_jumlah
        FROM 
            (
                SELECT 
                    a.prod_order1,
                    IF(COUNT(a.id) > 1 AND 
                       ((c.product LIKE '%IW%' AND (TIA413 BETWEEN 103 AND 107)) OR 
                        (c.product NOT LIKE '%IW%' AND (TIA413 BETWEEN 108 AND 112))), 1, 0) AS jumlah
                FROM 
                    scada_db1.ppi_ilbfiller1 a
                INNER JOIN 
                    aio_iot_oci1.mst_prodidentity c ON a.prod_order1 = c.prod_order
                GROUP BY 
                    prod_order1

                UNION

                SELECT 
                    pif.prod_order1,
                    IF(COUNT(pif.id) > 1, 1, 0) AS jumlah
                FROM 
                    scada_db1.ppi_ilbfiller1 pif
                WHERE 
                    (
                        (FICA411 > 17952 OR FICA411 < 10772)
                        OR 
                        (FICA411 > 22609 OR FICA411 < 13566)
                        OR 
                        (FICA411 > 30011.01 OR FICA411 < 18006.61)
                    )
                GROUP BY 
                    pif.prod_order1

                union

                SELECT 
                    cpaf.prod_order1,
                    IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
                from 
                    scada_db1.cttn_prod_area_filling1 cpaf
                where 
                    cpaf.Pressure_Filling_Chamber < 1
                GROUP BY 
                    cpaf.prod_order1

                union

                SELECT 
                    cpaf.prod_order1,
                    IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
                from 
                    scada_db1.cttn_prod_area_filling1 cpaf
                where 
                    cpaf.Pressure_Transfer_Table < 1
                GROUP BY 
                    cpaf.prod_order1

                union

                SELECT 
                    cpaf.prod_order1,
                    IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
                from 
                    scada_db1.cttn_prod_area_filling1 cpaf
                where 
                    cpaf.Pressure_Cap_Cool < 1
                GROUP BY 
                    cpaf.prod_order1

                union

                SELECT 
                    cpaf.prod_order1,
                    IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
                from 
                    scada_db1.cttn_prod_area_filling1 cpaf
                where 
                    cpaf.Pressure_Cap_Steam < 1
                GROUP BY 
                    cpaf.prod_order1

                union

                SELECT 
                    cpaf.prod_order1,
                    IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
                from 
                    scada_db1.cttn_prod_area_filling1 cpaf
                where 
                    cpaf.Rotary_Speed > 49.5
                GROUP BY 
                    cpaf.prod_order1

                union

                SELECT 
                    cpaf.prod_order1,
                    IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
                from 
                    scada_db1.cttn_prod_area_filling1 cpaf
                where 
                    cpaf.Press_Steam < 100 OR cpaf.Press_Steam > 150
                GROUP BY 
                    cpaf.prod_order1

            ) combined_data
        GROUP BY 
            prod_order1

    ) ccp on a.prod_order = ccp.prod_order1
WHERE date_format(a.tgl, '%Y') = '2023'
GROUP BY a.tgl, a.lotno, a.prod_order, a.product, a.prod_start
ORDER BY a.tgl DESC
LIMIT 24;

            `);
            res.status(200).send({
                message: "Get data success",
                data: query[0],
            });
        } catch (error) {
            console.log(error);
            res.status(500).send({
                message: "Get data failed",
                data: [],
            });
        }
    },

    getFlowReleaseOCI2: async (req, res) => {
        try {
            let query;
            query = await iot_oci2.query(`
            select 
a.tgl,
a.lotno,
a.prod_order,
a.product,
DATEDIFF(NOW(), a.prod_start) AS fg_quarantine,
IF(SUM(mikro.simpulan) = 0, 7, 0) AS sim_mikro,
IF(SUM(ipc.simpulan) = 0, 7, 0) AS sim_ipc,
COUNT(inspeksi.id) AS inspeksi,
COUNT(capa.id) AS capa,
count(form.id) as dynamic_form,
SUM(ccp.total_jumlah) as ccp
from mst_prodidentity a
LEFT JOIN 
    (
        SELECT
            lotno,
            CASE
                WHEN (b.name = 'ALVIN JAUHAR AL KHOIR') THEN 0
                ELSE -1
            END AS simpulan
        FROM
        aio_iot_oci1.tr_history2 a
        JOIN
        aio_iot_oci1.v_employee b ON a.job_owner = b.nik
        WHERE 
            a.tgl_proses IS NOT NULL AND b.name = 'ALVIN JAUHAR AL KHOIR'
    ) mikro ON a.lotno = mikro.lotno
LEFT JOIN 
    (
        SELECT
            lotno,
            CASE
                WHEN (b.name = 'HARY AGUSTIAWAN') THEN 0
                ELSE -1
            END AS simpulan
        FROM
        aio_iot_oci1.tr_history2 a
        JOIN
        aio_iot_oci1.v_employee b ON a.job_owner = b.nik
        WHERE 
            a.tgl_proses IS NOT NULL AND b.name = 'HARY AGUSTIAWAN'
    ) ipc ON a.lotno = ipc.lotno
left join 
	(
		select
			id,
			pro,
			status_approval
		from
			aio_iot_oci1.tr_inspection_capa_h
		where 
			status_approval >= 1
	) inspeksi on a.prod_order = inspeksi.pro
left join 
	(
		select
			id,
			pro,
			status_approval
		from
			aio_iot_oci1.tr_inspection_capa_h
		where 
			status_approval = 4
	) capa on a.prod_order = capa.pro
left join 
	(
		select 
			id,
			lotno,
			pro
		from 
			tr_summary_perilisan
) form on a.lotno = form.lotno
left join 
	(
		SELECT 
    prod_order2,
    SUM(jumlah) AS total_jumlah
FROM 
    (
        SELECT 
            a.prod_order2,
            IF(COUNT(a.id) > 1 AND 
               ((c.product LIKE '%IW%' AND (TIA413 BETWEEN 103 AND 107)) OR 
                (c.product NOT LIKE '%IW%' AND (TIA413 BETWEEN 108 AND 112))), 1, 0) AS jumlah
        FROM 
            scada_db1.ppi_ilbfiller2 a
        INNER JOIN 
            aio_iot_oci1.mst_prodidentity c ON a.prod_order2 = c.prod_order
        GROUP BY 
            prod_order2

        UNION

        SELECT 
            pif.prod_order2,
            IF(COUNT(pif.id) > 1, 1, 0) AS jumlah
        FROM 
            scada_db1.ppi_ilbfiller2 pif
        WHERE 
    		(
        		(FICA411 > 17952 OR FICA411 < 10772)
        	OR 
        		(FICA411 > 22609 OR FICA411 < 13566)
        	OR 
        		(FICA411 > 30011.01 OR FICA411 < 18006.61)
    		)

        GROUP BY 
            pif.prod_order2
            
        union
        
        SELECT 
        	cpaf.prod_order2,
        	IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
        from 
        	scada_db1.cttn_prod_area_filling2 cpaf
        where 
        	cpaf.Pressure_Filling_Chamber < 1
        GROUP BY 
            cpaf.prod_order2
        
         union
        
        SELECT 
        	cpaf.prod_order2,
        	IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
        from 
        	scada_db1.cttn_prod_area_filling2 cpaf
        where 
        	cpaf.Pressure_Transfer_Table < 1
        GROUP BY 
            cpaf.prod_order2
            
        union
        
        SELECT 
        	cpaf.prod_order2,
        	IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
        from 
        	scada_db1.cttn_prod_area_filling2 cpaf
        where 
        	cpaf.Pressure_Cap_Cool < 1
        GROUP BY 
            cpaf.prod_order2
        
        union
        
        SELECT 
        	cpaf.prod_order2,
        	IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
        from 
        	scada_db1.cttn_prod_area_filling2 cpaf
        where 
        	cpaf.Pressure_Cap_Steam < 1
        GROUP BY 
            cpaf.prod_order2
            
        union
        
        SELECT 
        	cpaf.prod_order2,
        	IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
        from 
        	scada_db1.cttn_prod_area_filling2 cpaf
        where 
        	cpaf.Rotary_Speed > 49.5
        GROUP BY 
            cpaf.prod_order2
            
        union
        
        SELECT 
        	cpaf.prod_order2,
        	IF(COUNT(cpaf.id)>1, 1, 0) AS jumlah
        from 
        	scada_db1.cttn_prod_area_filling2 cpaf
        where 
        	cpaf.Press_Steam < 100 OR cpaf.Press_Steam > 150
        GROUP BY 
            cpaf.prod_order2
            
            
    ) combined_data
GROUP BY 
    prod_order2

		
	) ccp on a.prod_order = ccp.prod_order2
where date_format(a.tgl, '%Y') = '2023'
group by a.lotno
order by a.tgl DESC
limit 24
            `);
            res.status(200).send({
                message: "Get data success",
                data: query[0],
            });
        } catch (error) {
            console.log(error);
            res.status(500).send({
                message: "Get data failed",
                data: [],
            });
        }
    }
}